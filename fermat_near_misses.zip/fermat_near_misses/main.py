def calculate_relative_miss(x, y, z, n):
    x_pow_n = x ** n
    y_pow_n = y ** n
    z_pow_n = z ** n

    miss_1 = abs(x_pow_n + y_pow_n - z_pow_n)
    miss_2 = abs(x_pow_n + y_pow_n - (z + 1) ** n)

    relative_miss = min(miss_1, miss_2) / (x_pow_n + y_pow_n) * 100
    return relative_miss


def find_near_misses(n, k):
    smallest_relative_miss = float('inf')
    best_x, best_y, best_z = None, None, None

    for x in range(10, k + 1):
        for y in range(10, k + 1):
            for z in range(1, k + 1):
                relative_miss = calculate_relative_miss(x, y, z, n)
                if relative_miss < smallest_relative_miss:
                    smallest_relative_miss = relative_miss
                    best_x, best_y, best_z = x, y, z

    print("Smallest Relative Miss: {:.2f}%".format(smallest_relative_miss))
    print("Best x: {}, Best y: {}, Best z: {}".format(best_x, best_y, best_z))


if __name__ == "__main__":
    print("Near Misses of Fermat's Last Theorem Finder")

    while True:
        try:
            n = int(input("Enter the value of n (2 < n < 12): "))
            if 2 < n < 12:
                break
            else:
                print("Invalid input. 'n' must be greater than 2 and less than 12.")
        except ValueError:
            print("Invalid input. Please enter a valid integer for 'n'.")

    while True:
        try:
            k = int(input("Enter the value of k (k > 10): "))
            if k > 10:
                break
            else:
                print("Invalid input. 'k' must be greater than 10.")
        except ValueError:
            print("Invalid input. Please enter a valid integer for 'k'.")

    find_near_misses(n, k)
