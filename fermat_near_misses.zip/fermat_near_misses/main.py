# Program: Near Misses of Fermat's Last Theorem Finder
# File: fermat_near_misses.py
# External files: N/A
# External files created: N/A
# Programmers: [Pranavi Mittapalli], [Rahul Chituprolu]
# Email addresses: [pranavimittapalli@lewisu.edu], [rahulchituprolu@lewisu.edu]
# Course Number and Section: [60500], [001]
# Date finished and submitted: [30/7/2023]
# Explanation: This program helps an interactive user search for "near misses" of the form (x, y, z, n, k)
# in the formula x^n + y^n = z^n, where x, y, z, n, k are positive integers, where 2 < n < 12, where 10 <= x <= k,
# and where 10 <= y <= k. It calculates the relative miss for each possible combination of x, y, and z, and displays
# the smallest relative miss along with the corresponding values of x, y, and z to the user.
# Function to calculate the relative miss for a given x, y, z, and n

def calculate_relative_miss(x, y, z, n):
    # Calculate x^n, y^n, and z^n
    x_pow_n = x ** n
    y_pow_n = y ** n
    z_pow_n = z ** n

    # Calculate two possible misses and find the smallest
    miss_1 = abs(x_pow_n + y_pow_n - z_pow_n)
    miss_2 = abs(x_pow_n + y_pow_n - (z + 1) ** n)

    # Calculate the relative miss as a percentage
    relative_miss = min(miss_1, miss_2) / (x_pow_n + y_pow_n) * 100
    return relative_miss


def find_near_misses(n, k):
    smallest_relative_miss = float('inf')
    best_x, best_y, best_z = None, None, None
    # Loop through all possible combinations of x, y, and z
    for x in range(10, k + 1):
        for y in range(10, k + 1):
            for z in range(1, k + 1):
                relative_miss = calculate_relative_miss(x, y, z, n)
                # Keep track of the smallest relative miss and corresponding values of x, y, and z
                if relative_miss < smallest_relative_miss:
                    smallest_relative_miss = relative_miss
                    best_x, best_y, best_z = x, y, z
    # Print the results
    print("Smallest Relative Miss: {:.2f}%".format(smallest_relative_miss))
    print("Best x: {}, Best y: {}, Best z: {}".format(best_x, best_y, best_z))


if __name__ == "__main__":
    print("Near Misses of Fermat's Last Theorem Finder")
    # Get user input for n and k, validating the inputs
    while True:
        try:
            n = int(input("Enter the value of n (2 < n < 12): "))
            if 2 < n < 12:
                break
            else:
                print("Invalid input. 'n' must be greater than 2 and less than 12.")
        except ValueError:
            print("Invalid input. Please enter a valid integer for 'n'.")

    while True:
        try:
            k = int(input("Enter the value of k (k > 10): "))
            if k > 10:
                break
            else:
                print("Invalid input. 'k' must be greater than 10.")
        except ValueError:
            print("Invalid input. Please enter a valid integer for 'k'.")
    # Find and display near misses for Fermat's Last Theorem
    find_near_misses(n, k)
